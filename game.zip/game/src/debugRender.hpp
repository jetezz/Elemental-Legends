#pragma once



#include <vector>
#include <iostream>
#include "entity/entity.hpp"





//FUNCIONES

void renderDebug(std::vector<unique_ptr <entity>> &ArrayEntity);










