
#include "moveTo.hpp"
#include "../blackboard.hpp"

bool moveTo::run(blackboard *data){

   data->b_bot->moveTo(data->wayPoint);

     auto dx = data->b_bot->getposition().X-data->wayPoint.X;
     auto dz = data->b_bot->getposition().Z-data->wayPoint.Z;

     auto dis = sqrtf(dx*dx+dz*dz);
  
     if(dis<=3){
        data->b_bot->removeWaypoint();
     }

   // cout << "distancia al punto: " << dis << endl;
     
    return true;
}
