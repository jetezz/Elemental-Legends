#include "entity/gameObject.hpp"
#include "entity/entity.hpp"
#include "CONSTANTES.hpp"
#include "motor_fisicas/fisicas.hpp"


#define SIZE_POINTS  8


/////////////////
////Funciones////
/////////////////



//Metodo que calcula el unto maximo y el punto minimo y luego a partir de ellos saca la distancia 

float gameObject::calculateMinAndMaxProjectionPoints(std::vector<float> &points){
	float min = points[0], max = points[0];
	for(size_t i = 1; i < points.size(); ++i){
		if(points[i] < min){
			min = points[i];
		}
		else if(points[i] > max){
			max = points[i];
		}
	}
    float a=(max/2)-(min/2);
	return a;
}

//Metodos que devuelven los valores de x y o z


//Este metodo te consigue todas las x,y o z de los 8 puntos de la boundig box para luego pasarselos al metodo que calcula la distancia entre el punto maximo y el minimo


//Metodo que detecta las colisiones entre el array entidades y la entidad que lo llama.



//Metodo que detecta la colision entre los GameObject y la entidad que llama , tiene el mismo mecanismo que el metodo colision


void gameObject::actualizarPercentick(float percentick){

    if(percentick<1){
    float posicionMediaX=0;
    float posicionMediaY=0;
    float posicionMediaZ=0;

    
    posicionMediaX=getpositionLast().X*(1-percentick)+getposition().X*percentick;
    posicionMediaY=getpositionLast().Y*(1-percentick)+getposition().Y*percentick;
    posicionMediaZ=getpositionLast().Z*(1-percentick)+getposition().Z*percentick;
    
    float rotacionMediaX=0;
    float rotacionMediaY=0;
    float rotacionMediaZ=0;

   
    rotacionMediaX=getRotationLast().X*(1-percentick)+getRotation().X*percentick;
    rotacionMediaY=getRotationLast().Y*(1-percentick)+getRotation().Y*percentick;
    rotacionMediaZ=getRotationLast().Z*(1-percentick)+getRotation().Z*percentick;



vector3d posicionMedia=vector3d(posicionMediaX,posicionMediaY,posicionMediaZ);
vector3d rotacionMedia=vector3d(rotacionMediaX,rotacionMediaY,rotacionMediaZ);

      fachada->cambiarPosicion(posicionMedia,getImage(),rotacionMedia);
    }
}
void gameObject::initPuntos(){
    puntos.resize(8);
    puntos=fisicas::getPuntos(posicion,hitbox, rotacionLast);
    
}






///////
//GET//
///////

vector3d &gameObject::getposition(){
    return posicion;
}
vector3d &gameObject::getpositionLast(){
    return posicionLast;
}
MyNode_t &gameObject::getImage(){
    return Imagen;
}

vector3d &gameObject::getRotation(){
    return rotacion;
}
vector3d &gameObject::getRotationLast(){
    return rotacionLast;
}
vector3d &gameObject::getVelocidadRotacion(){
    return velocidadRotacion;
}
vector3d &gameObject::getHitBox(){
    return hitbox;
}
 std::chrono::time_point<std::chrono::system_clock> &gameObject::getTiempo(){
    return tiempo;
}
int gameObject::getPower(){
    return power;
}
vector<vector3d>& gameObject::getPuntos(){
    return puntos;
}
    




///////
//SET//
///////

void gameObject::setImage(MyNode_t& img){
    Imagen = img;
 }

 void gameObject::setPosition(vector3d vec){
    posicion=vec;
}
void gameObject::setPositionLast(vector3d vec){
    posicionLast=vec;
}


void gameObject::setRotation(vector3d vec){
    rotacion=vec;
}
void gameObject::setRotationLast(vector3d vec){
    rotacionLast=vec;
}
void gameObject::setVelocidadRotacion(vector3d vec){
    velocidadRotacion=vec;
}

void gameObject::setHitBox(vector3d vec){

    hitbox=vec;
  
}
void gameObject::setTiempo(std::chrono::time_point<std::chrono::system_clock> time){
    tiempo=time;
}
void gameObject::setPower(int num){
    power=num;
}
void gameObject::setPuntos(vector <vector3d> pun){
    puntos=pun;
}
