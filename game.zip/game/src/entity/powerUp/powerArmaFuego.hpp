#pragma once

#include "motor_grafico/vector3d.hpp"
#include "motor_grafico/mynode.hpp"

#include"entity/powerUp/powerUp.hpp"

class powerArmaFuego : public powerUp {

    public:
    powerArmaFuego(vector3d& pos);
    void efectoPowerUp(entity &enti);
    //FUNCIONES
   
    
   

    //get
   

    //set
 

    private:

    //VARIABLES
    
   
    
};
