#include <iostream>
#include "game.hpp"

fachadaIrrlicht * fachadaIrrlicht::_instance = nullptr;


int main (){
    
        game juego;
        juego.start();   
 


    return 0;
}

