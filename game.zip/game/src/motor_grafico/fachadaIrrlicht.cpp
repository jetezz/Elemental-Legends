#include "fachadaIrrlicht.hpp"
#include "irrlicht/driverChoice.h"
#include "motor_grafico/mynode.hpp"
#include "motor_grafico/vector3d.hpp"
#include <math.h>
#include <string>




fachadaIrrlicht *fachada = fachadaIrrlicht::getFachada();

/////////////////////////////////
/////funciones clase fachada/////
/////////////////////////////////







fachadaIrrlicht::~fachadaIrrlicht()
{
	delete _instance;
	_instance = nullptr;
}

void fachadaIrrlicht::cambiarPosicion(vector3d& vec,MyNode_t& img,vector3d& rotacion){
    
    img.getNode()->setPosition(vec.transformar());
    img.setRotation(rotacion);


    
    
    img.getNode()->updateAbsolutePosition();   
    img.setPoints();
    
    
 //img.getNode()->setScale(tran.transformar());

}

void fachadaIrrlicht::updateMouse(){
    
	if(device && device->isWindowFocused()){
        auto oldPos = device->getCursorControl()->getPosition();
		device->getCursorControl()->setPosition(0.5f,0.5f);
        auto newPos = device->getCursorControl()->getPosition();
        receiver.reset(oldPos.X, oldPos.Y, newPos.X,newPos.Y);
    }
	
            
}
void fachadaIrrlicht::setMouseVisibility(bool i){
 
        device->getCursorControl()->setVisible(i);

}
float fachadaIrrlicht::getMouseDx(){
	return receiver.MouseState.Dx;
}

float fachadaIrrlicht::getMouseDy(){
	return receiver.MouseState.Dy;
}

/////////////////////
///tipos de objetos//
/////////////////////

/*
*Pinta una línea desde el punto inicial al final
* @param PosInicial es el punto inicial de la linea
* @param PosFin es el punto final de la linea
* @param color es el color que tendrá la linea. Un vector3d con RGB
*/
void fachadaIrrlicht::drawLine(vector3d posInicial, vector3d posFin, vector3d color){
   driver->draw3DLine(posInicial.transformar(),posFin.transformar(),irr::video::SColor(color.X,color.Y,color.Z,255));
}


 void fachadaIrrlicht::createmapa(int tam){
	node = smgr->addCubeSceneNode(tam);//dibuja un cubo
    
    node->setPosition(vector3d(0,-tam/2,0).transformar());
    node->setMaterialTexture(0, driver->getTexture("resources/tierra2.jpg"));
    node->setMaterialFlag(irr::video::EMF_LIGHTING, false);
	
	
	
}

 irr::scene::ISceneNode* fachadaIrrlicht::createEnemy(vector3d &vec,vector3d &hit){
	node = smgr->addCubeSceneNode(hit.X);//dibuja un cubo

    node->setPosition(vec.transformar());
    node->setMaterialTexture(0, driver->getTexture("resources/wall.jpg"));
    node->setMaterialFlag(irr::video::EMF_LIGHTING, false);
	
	
	return node;
}


 irr::scene::ISceneNode* fachadaIrrlicht::createBulletNeutral(vector3d &vec,vector3d &hit){
	node = smgr->addCubeSceneNode(hit.X);//dibuja un cubo

    node->setPosition(vec.transformar());
    node->setMaterialTexture(0, driver->getTexture("resources/neutral2.jpg"));
    node->setMaterialFlag(irr::video::EMF_LIGHTING, false);
	
	
	return node;
}

 irr::scene::ISceneNode* fachadaIrrlicht::createBulletFuego(vector3d &vec,vector3d &hit){
	node = smgr->addCubeSceneNode(hit.X);//dibuja un cubo

    node->setPosition(vec.transformar());
    node->setMaterialTexture(0, driver->getTexture("resources/Fuego2.jpg"));
    node->setMaterialFlag(irr::video::EMF_LIGHTING, false);
	
	
	return node;
}
 irr::scene::ISceneNode* fachadaIrrlicht::createBulletAgua(vector3d &vec,vector3d &hit){
	node = smgr->addCubeSceneNode(hit.X);//dibuja un cubo

    node->setPosition(vec.transformar());
    node->setMaterialTexture(0, driver->getTexture("resources/agua2.jpg"));
    node->setMaterialFlag(irr::video::EMF_LIGHTING, false);
	
	
	return node;
}
 irr::scene::ISceneNode* fachadaIrrlicht::createBulletTierra(vector3d &vec,vector3d &hit){
	node = smgr->addCubeSceneNode(hit.X);//dibuja un cubo

    node->setPosition(vec.transformar());
    node->setMaterialTexture(0, driver->getTexture("resources/tierra2.jpg"));
    node->setMaterialFlag(irr::video::EMF_LIGHTING, false);
	
	
	return node;
}
 irr::scene::ISceneNode* fachadaIrrlicht::createBulletAire(vector3d &vec,vector3d &hit){
	node = smgr->addCubeSceneNode(hit.X);//dibuja un cubo

    node->setPosition(vec.transformar());
    node->setMaterialTexture(0, driver->getTexture("resources/viento2.jpg"));
    node->setMaterialFlag(irr::video::EMF_LIGHTING, false);
	
	
	return node;
}

 irr::scene::ISceneNode* fachadaIrrlicht::createCofre(vector3d &vec,vector3d& hit){
	node = smgr->addCubeSceneNode(5);//dibuja un cubo

    node->setPosition(vec.transformar());
    node->setMaterialTexture(0, driver->getTexture("resources/chest.jpg"));
    node->setMaterialFlag(irr::video::EMF_LIGHTING, false);
	
	
	return node;
}
 irr::scene::ISceneNode* fachadaIrrlicht::createVida(vector3d &vec,vector3d& hit){
	node = smgr->addCubeSceneNode(2);//dibuja un cubo

    node->setPosition(vec.transformar());
    node->setMaterialTexture(0, driver->getTexture("resources/powerVida2.png"));
    node->setMaterialFlag(irr::video::EMF_LIGHTING, false);
	
	
	return node;
}


/////HUD

void fachadaIrrlicht::initHud(){
    
    background->clear();
    
    env = device->getGUIEnvironment();
    hudPantalla= env->addImage(driver->getTexture("resources/hud2.png"),	irr::core::position2d<int>(10,200));
    hudArmaNeutral(1);
    hudMunicion();
    balas=env->addStaticText(L"10000", irr::core::rect<irr::s32>(120,435,250,500));
    vida=env->addStaticText(L"20", irr::core::rect<irr::s32>(150,435,250,500));
    tier= env->addImage(driver->getTexture("resources/bronce.png"),	irr::core::position2d<int>(420,450));
    
}


bool TestRayOBBIntersection(
	vector3d origen,
    vector3d fin,
    MyNode_t& nodo
){  

    glm::vec3 pInicio {};

    pInicio.x = origen.X;
    pInicio.y = origen.Y;
    pInicio.z = origen.Z;

    glm::vec3 pFinal {};
    
    pFinal.x = fin.X;
    pFinal.y = fin.Y;
    pFinal.z = fin.Z;

    //Punto medio
    glm::vec3 midLinea = (pInicio + pFinal);
    midLinea.x = midLinea.x * 0.5;
    midLinea.y = midLinea.y * 0.5;
    midLinea.z = midLinea.z * 0.5;
    
    //Dirección
    glm::vec3 dir = glm::normalize(pFinal - pInicio);
    
    auto dx = pFinal.x-pInicio.x;
    auto dy = pFinal.y-pInicio.y;
    auto dz = pFinal.z-pInicio.z;

    //Media distancia
    auto halfDistance = sqrtf(dx*dx+dy*dy+dz*dz) * 0.5;

    glm::vec3 AABBmin {};
    AABBmin.x = nodo.getMinAABB().X;
    AABBmin.y = nodo.getMinAABB().Y;
    AABBmin.z = nodo.getMinAABB().Z;

    glm::vec3 AABBmax {};
    AABBmax.x = nodo.getMaxAABB().X;
    AABBmax.y = nodo.getMaxAABB().Y;
    AABBmax.z = nodo.getMaxAABB().Z;

    auto e = AABBmax - AABBmin; //Box extent
    e.x  = e.x * 0.5;
    e.y  = e.y * 0.5;
    e.z  = e.z * 0.5;

    auto t = AABBmax + AABBmin; //Box Center - linea center
    t.x  = t.x * 0.5;
    t.y  = t.y * 0.5;
    t.z  = t.z * 0.5;
    t = t - midLinea;

        if ((fabs(t.x) > e.x + halfDistance * fabs(dir.x)) ||
            (fabs(t.y) > e.y + halfDistance * fabs(dir.y)) ||
            (fabs(t.z) > e.z + halfDistance * fabs(dir.z)) )
            return false;

		auto r = e.y * fabs(dir.z) + e.z * fabs(dir.y);
		if (fabs(t.y*dir.z - t.z*dir.y) > r )
			return false;

		r = e.x * fabs(dir.z) + e.z * fabs(dir.x);
		if (fabs(t.z*dir.x - t.x*dir.z) > r )
			return false;

        r = e.x * fabs(dir.z) + e.y * fabs(dir.x);
        if (fabs(t.x*dir.y - t.y*dir.x) > r)
            return false;

		return true;

}


//HUD ARMAS
void fachadaIrrlicht::hudArmaNeutral(uint8_t opcion){

    if(opcion==1){
        ArmaNeutral= env->addImage(driver->getTexture("resources/basico.jpg"),	irr::core::position2d<int>(280,410));
    }
    else{
        ArmaNeutral->remove();
    }

}
void fachadaIrrlicht::hudArmaAgua(uint8_t opcion){
    if(opcion==1){
        ArmaAgua= env->addImage(driver->getTexture("resources/rafaga.png"),	irr::core::position2d<int>(340,410));
    }
    else{
        ArmaAgua->remove();
    }

}
void fachadaIrrlicht::hudArmaAire(uint8_t opcion){
    if(opcion==1){
        ArmaAire= env->addImage(driver->getTexture("resources/vaiven.jpg"),	irr::core::position2d<int>(400,410));
      }
    else{
        ArmaAire->remove();
    }
}
void fachadaIrrlicht::hudArmaFuego(uint8_t opcion){
    if(opcion==1){
        ArmaFuego= env->addImage(driver->getTexture("resources/explosion.png"),	irr::core::position2d<int>(460,410));
      }
    else{
        ArmaFuego->remove();
    }
}
void fachadaIrrlicht::hudArmaTierra(uint8_t opcion){
    if(opcion==1){
        ArmaTierra= env->addImage(driver->getTexture("resources/sniper.png"),	irr::core::position2d<int>(520,410));
      }
    else{
        ArmaTierra->remove();
    }

}

void fachadaIrrlicht::hudArmaNeutralb(uint8_t opcion){
    if(opcion==1){
        ArmaNeutral= env->addImage(driver->getTexture("resources/basicob.jpg"),	irr::core::position2d<int>(280,410));
    }
    else{
        ArmaNeutral->remove();
    }

}


void fachadaIrrlicht::hudArmaAguab(uint8_t opcion){
    if(opcion==1){
        ArmaAgua= env->addImage(driver->getTexture("resources/rafagab.png"),	irr::core::position2d<int>(340,410));
    }
    else{
        ArmaAgua->remove();
    }

}
void fachadaIrrlicht::hudArmaAireb(uint8_t opcion){
    if(opcion==1){
        ArmaAire= env->addImage(driver->getTexture("resources/vaivenb.jpg"),	irr::core::position2d<int>(400,410));
      }
    else{
        ArmaAire->remove();
    }
}
void fachadaIrrlicht::hudArmaFuegob(uint8_t opcion){
    if(opcion==1){
        ArmaFuego= env->addImage(driver->getTexture("resources/explosionb.png"),	irr::core::position2d<int>(460,410));
      }
    else{
        ArmaFuego->remove();
    }
}
void fachadaIrrlicht::hudArmaTierrab(uint8_t opcion){
    if(opcion==1){
        ArmaTierra= env->addImage(driver->getTexture("resources/sniperb.png"),	irr::core::position2d<int>(520,410));
      }
    else{
        ArmaTierra->remove();
    }

}
void fachadaIrrlicht::hudMunicion(){
    env->addImage(driver->getTexture("resources/municion2.jpg"),	irr::core::position2d<int>(50,430));
}


//HUD POWERUP
void fachadaIrrlicht::hudPowerVida(uint8_t opcion){
    if(opcion==1){
        powerVida= env->addImage(driver->getTexture("resources/powerVida2.png"),	irr::core::position2d<int>(520,450));
      }
    else{
        powerVida->remove();
    }

}
void fachadaIrrlicht::hudPowerVidab(uint8_t opcion){
    if(opcion==1){
        powerVida= env->addImage(driver->getTexture("resources/powerVida2b.png"),	irr::core::position2d<int>(520,450));
      }
    else{
        powerVida->remove();
    }

}
//HUD TIER

void fachadaIrrlicht::hudTier1(){
    
        tier->remove();
        tier= env->addImage(driver->getTexture("resources/bronce.png"),	irr::core::position2d<int>(420,450));
     
    
}
void fachadaIrrlicht::hudTier2(){
  
        tier->remove();
        tier= env->addImage(driver->getTexture("resources/plata.png"),	irr::core::position2d<int>(420,450));
      
   
    
}

void fachadaIrrlicht::hudTier3(){
    
        tier->remove();
        tier= env->addImage(driver->getTexture("resources/oro.png"),	irr::core::position2d<int>(420,450));
    
    
    
}



//HUD MENSAJES
void fachadaIrrlicht::activarMensaje(){
    
    mensaje= env->addImage(driver->getTexture("resources/pulsae.png"),	irr::core::position2d<int>(250,300)); 

} 



void fachadaIrrlicht::desactivarMensaje(){
    mensaje->remove();

}


void fachadaIrrlicht::numeroBalas(int num){
    balas->remove();

    string s=to_string(num);
    std::wstring widestr = std::wstring(s.begin(), s.end());
    const wchar_t* widecstr = widestr.c_str();
   
  
  balas=env->addStaticText(widecstr, irr::core::rect<irr::s32>(120,435,250,500));

}

void fachadaIrrlicht::numeroVida(int num){
    vida->remove();

    string s=to_string(num);
    std::wstring widestr = std::wstring(s.begin(), s.end());
    const wchar_t* widecstr = widestr.c_str();
   
  
  vida=env->addStaticText(widecstr, irr::core::rect<irr::s32>(150,435,250,500));

}
void fachadaIrrlicht::activarMensajeIntro(){
    intro=env->addImage(driver->getTexture("resources/intro.png"),	irr::core::position2d<int>(250,300)); 

}
void fachadaIrrlicht::estadisticaTiempo(float num){
    string s= "Tiempo=";
    s+=to_string(num);
    s +="s";
    std::wstring widestr = std::wstring(s.begin(), s.end());
    const wchar_t* widecstr = widestr.c_str();
   
  
  estTiempo=env->addStaticText(widecstr, irr::core::rect<irr::s32>(120,200,250,500));
}
void fachadaIrrlicht::estadisticaKills(int num){
    string s= "kills=";
     s +=to_string(num);   
    std::wstring widestr = std::wstring(s.begin(), s.end());
    const wchar_t* widecstr = widestr.c_str();
   
  
  estKills=env->addStaticText(widecstr, irr::core::rect<irr::s32>(120,400,250,500));
}


//para poner la imagen de fondo inicial, más adelante será un vídeo
void fachadaIrrlicht::crearinterfaceinicio(){
    background = device->getGUIEnvironment();
    background->addImage(driver->getTexture("resources/index.jpg"), irr::core::position2d<int>(1,1));
}

//para poner la imagen de fondo y de los botones en el menu
void fachadaIrrlicht::crearinterfacemenu(){ 
    background->clear();
   // background2 = device->getGUIEnvironment();
    background->addImage(driver->getTexture("resources/image-450w-764304961.jpg"), irr::core::position2d<int>(1,1));
    background->addImage(driver->getTexture("resources/32216368-jugar-icono-web-botón.jpg"), irr::core::position2d<int>(300,120));
   background->addImage(driver->getTexture("resources/56661091-créditos-icono-botón-de-internet-sobre-fondo-blanco-.jpg"), irr::core::position2d<int>(300,220));
    background->addImage(driver->getTexture("resources/56660392-icono-salir-botón-de-internet-sobre-fondo-blanco-.jpg"), irr::core::position2d<int>(300,320));
}
//para cambiar la imagen de la opcion seleccionada
void fachadaIrrlicht::selectOption(int option){
    
    if(option==1){
        background->addImage(driver->getTexture("resources/32360149-jugar-icono-web-botón.jpg"), irr::core::position2d<int>(300,120));
        background->addImage(driver->getTexture("resources/56661091-créditos-icono-botón-de-internet-sobre-fondo-blanco-.jpg"), irr::core::position2d<int>(300,220));
        background->addImage(driver->getTexture("resources/56660392-icono-salir-botón-de-internet-sobre-fondo-blanco-.jpg"), irr::core::position2d<int>(300,320));
    }else if(option==2){
        background->addImage(driver->getTexture("resources/32216368-jugar-icono-web-botón.jpg"), irr::core::position2d<int>(300,120));    
        background->addImage(driver->getTexture("resources/depositphotos_209352162-stock-photo-credits-icon-internet-button-white.jpg"), irr::core::position2d<int>(300,220));
        background->addImage(driver->getTexture("resources/56660392-icono-salir-botón-de-internet-sobre-fondo-blanco-.jpg"), irr::core::position2d<int>(300,320));
    }else if(option==3){
        background->addImage(driver->getTexture("resources/32216368-jugar-icono-web-botón.jpg"), irr::core::position2d<int>(300,120));
        background->addImage(driver->getTexture("resources/56661091-créditos-icono-botón-de-internet-sobre-fondo-blanco-.jpg"), irr::core::position2d<int>(300,220));
        background->addImage(driver->getTexture("resources/53229807-icono-salir-botón-de-internet-sobre-fondo-blanco-.jpg"), irr::core::position2d<int>(300,320));
    }
    
}

//para poner la imagen de fondo y del personaje inicial
void fachadaIrrlicht::crearinterfacepersonajes(){ 
    background->clear();///////////ANYADIR LAS FOTOS///////////////////////
   // background2 = device->getGUIEnvironment();
    background->addImage(driver->getTexture("resources/fondopersonajes.png"), irr::core::position2d<int>(1,1));
    background->addImage(driver->getTexture("resources/aire.jpg"), irr::core::position2d<int>(225,60));
    background->addImage(driver->getTexture("resources/flechasizquierda.png"), irr::core::position2d<int>(100,220));
    background->addImage(driver->getTexture("resources/flechasderecha.png"), irr::core::position2d<int>(500,220));
   //background->addImage(driver->getTexture("resources/56661091-créditos-icono-botón-de-internet-sobre-fondo-blanco-.jpg"), irr::core::position2d<int>(300,220));
   // background->addImage(driver->getTexture("resources/56660392-icono-salir-botón-de-internet-sobre-fondo-blanco-.jpg"), irr::core::position2d<int>(300,320));
}

//para cambiar la imagen del personajes escogido
void fachadaIrrlicht::selectCharacter(int option){
    ///////////////TERMINAR DE HACER////////////////
    if(option==0){
         background->addImage(driver->getTexture("resources/aire.jpg"), irr::core::position2d<int>(225,60));
    }else if(option==1){
        background->addImage(driver->getTexture("resources/fire.jpg"), irr::core::position2d<int>(225,60));
    }else if(option==2){
        background->addImage(driver->getTexture("resources/tierra.jpg"), irr::core::position2d<int>(225,60));
    }else if(option==3){
        background->addImage(driver->getTexture("resources/luz.jpg"), irr::core::position2d<int>(225,60));
    }else if(option==4){
        background->addImage(driver->getTexture("resources/oscurity.jpg"), irr::core::position2d<int>(225,60));
    }else if(option==5){
        background->addImage(driver->getTexture("resources/agua.jpg"), irr::core::position2d<int>(225,60));
    }
    
}