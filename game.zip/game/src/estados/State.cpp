#include "State.hpp"

 State::State()
{
    fachada = fachadaIrrlicht::getFachada();
}


