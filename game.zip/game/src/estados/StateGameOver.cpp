#include "StateGameOver.hpp"
#include "estados/StateMachine.hpp"
#include "input.hpp"

//Estado de juego



void StateGameOver::init()
{

}


void StateGameOver::input(StateMachine *stados)
{
  if(!primeraVez){
  estadistic=stados->getEstadisticas();
  primeraVez=true;
  }
  if(check_intro()){      
       stados->setMenuState();
    }
    primeraVez=true;
}

void StateGameOver::update(float deltaTime)
{
  if (primeraVez && !dibujado){
    fachada->env->clear();
    
    fachada->estadisticaTiempo(estadistic.tiempo);
    fachada->estadisticaKills(estadistic.muertes);
    fachada->activarMensajeIntro();
    dibujado=true;
  }
}

void StateGameOver::render(float percentick)
{
 
  
  
  fachada->smgr->drawAll();
  fachada->env->drawAll();
  fachada->driver->endScene();
}