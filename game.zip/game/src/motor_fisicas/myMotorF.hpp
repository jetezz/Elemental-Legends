#pragma once
#include "motor_grafico/vector3d.hpp"
#include <vector>




class entity;
class gameObject;
class MyNode_t;
class myMotorF
{
public:
    static vector3d move(vector3d &position, vector3d &velocidad);
   
    static bool colision(vector3d &posicion1,std::vector<vector3d> &puntos1,vector3d &posicion2,std::vector<vector3d> &puntos2);    
   
    static float gistancia(std::vector<vector3d> &puntos,int eje);
    static vector3d calcularHitBox(vector3d &posicion, vector3d &hitbox,vector3d &rotacion);
    static std::vector<vector3d> getPuntos(vector3d &posicion, vector3d &hitbox, vector3d &rotacion);
   
    enum eje{ejex,ejey,ejez};
};




