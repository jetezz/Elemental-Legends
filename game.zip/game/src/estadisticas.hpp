#pragma once
#include <chrono>

struct estadisticas{
   float tiempo {0};
    int muertes{0};

};