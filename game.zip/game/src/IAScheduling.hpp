#pragma once



#include <vector>
#include <iostream>
#include "entity/enemy.hpp"





class vector3d;
class entity;

//FUNCIONES

void runIAs(std::vector<unique_ptr <entity>> &ArrayEntity);








